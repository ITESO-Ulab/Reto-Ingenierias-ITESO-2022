package mx.ulab.practica5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import mx.ulab.practica5.databinding.ActivityShowNameBinding

class ShowNameActivity : AppCompatActivity() {

    private lateinit var binding : ActivityShowNameBinding
    private lateinit var tvNombre : TextView
    private lateinit var btnVolver : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityShowNameBinding.inflate(layoutInflater)
        setContentView(binding.root)
        tvNombre = binding.tvNombre

        btnVolver = binding.btnVolver

        getAndShowName()

        btnVolver.setOnClickListener {
            onBackPressed()
        }

    }

    fun getAndShowName() {
        val bundle = intent.extras
        val name = bundle?.get("name")
        tvNombre.text = name.toString()
    }

}