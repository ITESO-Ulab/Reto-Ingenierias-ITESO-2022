package mx.ulab.practica5

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import mx.ulab.practica5.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
     lateinit var binding: ActivityMainBinding

    private lateinit var editText : EditText
    private lateinit var button : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        editText = binding.editText
        button = binding.btnSiguiente

        button.setOnClickListener {
            checkValue()
        }

    }

    private fun checkValue() {
        if(editText.text.toString().isEmpty()) {
            Toast.makeText(this, "El nombre no puede estar vacío", Toast.LENGTH_SHORT).show()
        } else {
            val intent = Intent(this, ShowNameActivity::class.java)
            intent.putExtra("name", editText.text.toString())
            startActivity(intent)
        }
    }

}